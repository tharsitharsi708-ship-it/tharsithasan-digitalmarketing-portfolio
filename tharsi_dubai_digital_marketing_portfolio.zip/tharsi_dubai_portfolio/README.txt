THARSI THASAN — DUBAI DIGITAL MARKETING PORTFOLIO

Files:
- index.html: complete responsive website portfolio.

Preview:
Open index.html in a browser.

Publish free:
1. Create a GitHub account and a new repository.
2. Upload index.html to the repository root.
3. In repository Settings > Pages, select Deploy from a branch, choose main and /(root), then Save.
   OR import the repository into Vercel and deploy it as a static site.
4. Add the published URL to your CV and LinkedIn.

Before sending to employers:
- Add your phone number if you want it public.
- Add real screenshots or links to work you have permission to share.
- Check each project description and certification title for accuracy.
- Replace or remove any item that does not match your exact contribution.
